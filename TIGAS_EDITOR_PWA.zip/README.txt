TIGAS EDITOR - install on iPhone

1. Host this folder on any HTTPS address. The quickest way: open app.netlify.com/drop
   on a computer and drag this whole folder onto the page. You get a link like
   https://something.netlify.app
2. On the iPhone, open that link in Safari.
3. Tap Share, then "Add to Home Screen".
4. Open TIGAS from the home screen. It runs full screen and works offline.

Your project and imported videos are saved on the device (inside the app),
so they are still there when you reopen it.
